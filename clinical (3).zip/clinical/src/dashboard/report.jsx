import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { FiDownload, FiArrowLeft } from "react-icons/fi";
import { jsPDF } from "jspdf";

const Report = () => {
  const { reportId } = useParams();
  const [report, setReport] = useState(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const storedReport = localStorage.getItem(`report_${reportId}`);
    if (storedReport) {
      setReport(storedReport);
    } else {
      navigate("/dashboard");
    }
  }, [reportId, navigate]);

  const handleDownloadPDF = () => {
    setIsDownloading(true);
    const doc = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    });

    doc.setFontSize(20);
    doc.setFont("helvetica", "bold");
    doc.text("Consultation Report", 20, 20);

    doc.setFontSize(12);
    doc.setFont("helvetica", "normal");
    const splitText = doc.splitTextToSize(report, 170);
    doc.text(splitText, 20, 30);

    doc.save(`consultation_report_${new Date().toISOString()}.pdf`);
    setTimeout(() => setIsDownloading(false), 500);
  };

  const renderFormattedText = (text) => {
    const parts = text.split(/(\*\*.*?\*\*)/);
    return parts.map((part, index) => {
      if (part.startsWith("**") && part.endsWith("**")) {
        const boldText = part.slice(2, -2);
        return <strong key={index} className="font-bold text-gray-900">{boldText}</strong>;
      }
      return part;
    });
  };

  if (!report) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-gray-200 flex items-center justify-center">
        <div className="bg-white rounded-2xl shadow-xl p-8 flex flex-col items-center gap-6 animate-fade-in">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-indigo-600"></div>
          <span className="text-gray-900 text-lg font-semibold">Loading Your Report...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-gray-200 p-8">
      <div className="bg-white rounded-2xl shadow-xl max-w-5xl mx-auto p-10 transform transition-all duration-300 hover:shadow-2xl relative overflow-hidden">
        {/* Animated Background Element */}
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-100 to-transparent opacity-20 animate-pulse-slow pointer-events-none"></div>

        {/* Header */}
        <div className="flex justify-between items-center border-b border-gray-200 pb-6 mb-8">
          <h2 className="text-4xl font-extrabold text-gray-900 animate-slide-in flex items-center gap-2">
            <svg className="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 002 2h2" />
            </svg>
            Consultation Report
          </h2>
          <button
            onClick={() => navigate("/dashboard")}
            className="text-gray-600 hover:text-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 rounded-full p-2 transition-colors duration-200"
            title="Back to Dashboard"
            aria-label="Back to Dashboard"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Report Content */}
        <div className="prose prose-lg max-w-none text-gray-700 whitespace-pre-wrap bg-white p-8 rounded-xl shadow-inner border border-gray-100 hover:border-indigo-200 transition-all duration-300">
          {report.split("\n").map((line, index) => (
            <p
              key={index}
              className={`${
                line.match(/^\d+\./)
                  ? "font-bold text-indigo-700 mt-8 mb-4 text-2xl animate-fade-in"
                  : "text-gray-700 leading-relaxed"
              }`}
            >
              {renderFormattedText(line)}
            </p>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="mt-10 flex justify-end gap-6 relative z-10">
          <button
            onClick={handleDownloadPDF}
            disabled={isDownloading}
            className={`flex items-center gap-3 bg-indigo-600 text-white px-8 py-3 rounded-full shadow-lg transform transition-all duration-300 ${
              isDownloading
                ? "opacity-70 cursor-not-allowed"
                : "hover:bg-indigo-700 hover:scale-105 focus:ring-2 focus:ring-indigo-500"
            }`}
          >
            <FiDownload size={22} className={isDownloading ? "animate-bounce" : ""} />
            <span>{isDownloading ? "Downloading..." : "Download PDF"}</span>
          </button>
          <button
            onClick={() => navigate("/dashboard")}
            className="flex items-center gap-3 bg-gray-100 text-gray-800 px-8 py-3 rounded-full shadow-lg hover:bg-gray-200 transform hover:scale-105 transition-all duration-300 focus:ring-2 focus:ring-gray-300"
          >
            <FiArrowLeft size={22} />
            <span>Back to Dashboard</span>
          </button>
        </div>
      </div>

      {/* Download Animation Overlay */}
      {isDownloading && (
        <div className="fixed inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-8 flex flex-col items-center gap-6 animate-fade-in shadow-2xl">
            <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-indigo-600"></div>
            <span className="text-gray-900 text-lg font-semibold">Preparing PDF Download...</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default Report;