import asyncio
import websockets
import base64
import json
import os
import ffmpeg
from datetime import datetime
from test2 import SpeakerDiarizationSystem  # Importing from your provided test2.py

# Initialize the diarization system with your Hugging Face token
HF_TOKEN = "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"  # Replace with your actual token
diarization_system = SpeakerDiarizationSystem(hf_token=HF_TOKEN)

async def handle_connection(websocket):
    print(f"Handler called with websocket: {websocket}")
    
    try:
        async for message in websocket:
            print("Received message from client")
            data = json.loads(message)
            if "audio" not in data:
                await websocket.send(json.dumps({"error": "No audio data provided"}))
                continue

            # Decode base64 audio and save as temporary .webm file
            audio_bytes = base64.b64decode(data["audio"])
            temp_file = "temp_audio.webm"
            with open(temp_file, "wb") as f:
                f.write(audio_bytes)
            print(f"Wrote audio to {temp_file}")

            # Convert to WAV format using ffmpeg
            wav_file = f"recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}.wav"
            try:
                stream = ffmpeg.input(temp_file)
                stream = ffmpeg.output(stream, wav_file, acodec="pcm_s16le", ar=16000, ac=1)  # 16-bit PCM, 16kHz, mono
                ffmpeg.run(stream, overwrite_output=True, quiet=True)
                print(f"Converted to {wav_file}")
            except ffmpeg.Error as e:
                error_msg = f"FFmpeg error: {e.stderr.decode()}"
                await websocket.send(json.dumps({"error": error_msg}))
                print(error_msg)
                os.remove(temp_file)
                continue

            # Process audio with diarization (using test2.py)
            diarized_text = diarization_system.process_audio(wav_file, output_format="txt")
            if "Error" in diarized_text:
                await websocket.send(json.dumps({"error": diarized_text}))
                print(f"Diarization failed: {diarized_text}")
            else:
                # Store diarized text in a string and send to client
                print("Diarization complete, sending text to client")
                await websocket.send(json.dumps({
                    "status": "success",
                    "diarized_text": diarized_text
                }))

            # Clean up temporary files
            os.remove(temp_file)
            os.remove(wav_file)
            print("Cleaned up temporary files")

    except Exception as e:
        print(f"Error in connection: {e}")
        await websocket.send(json.dumps({"error": str(e)}))

async def main():
    print("Starting WebSocket server...")
    # Increase max_size to 10 MB (10 * 1024 * 1024 bytes)
    server = await websockets.serve(handle_connection, "localhost", 8765, max_size=10_485_760)
    print("WebSocket server running on ws://localhost:8765")
    await asyncio.Future()  # Run forever

if __name__ == "__main__":
    asyncio.run(main())