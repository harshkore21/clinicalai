import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from './login/Login.jsx';
import Dashboard from './dashboard/Dashboard.jsx';
import Report from './dashboard/report.jsx';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/report/:reportId" element={<Report />} />
      </Routes>
    </div>
  );
}

export default App;