import torch
import torchaudio
from pyannote.audio import Pipeline, Model
from pyannote.core import Segment
from transformers import WhisperProcessor, WhisperForConditionalGeneration
from typing import List
from dataclasses import dataclass
import json
import numpy as np
import os
import warnings
from huggingface_hub import login

# Suppress warnings
warnings.filterwarnings("ignore")

@dataclass
class SpeakerSegment:
    start: float
    end: float
    speaker: str
    text: str = ""

class SpeakerDiarizationSystem:
    def __init__(self, hf_token: str = None):
        """
        Initialize the speaker diarization system.
        
        Args:
            hf_token (str): Hugging Face authentication token (optional)
        """
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        torch.set_num_threads(4)
        
        if hf_token:
            login(token=hf_token)

        # Initialize models
        print("Loading speaker diarization model...")
        self.diarization_pipeline = Pipeline.from_pretrained(
            "pyannote/speaker-diarization-3.0",
            use_auth_token=hf_token
        ).to(self.device)
        
        print("Loading Whisper model...")
        self.whisper_processor = WhisperProcessor.from_pretrained("openai/whisper-tiny.en")
        self.whisper_model = WhisperForConditionalGeneration.from_pretrained("openai/whisper-tiny.en")
        self.whisper_model.config.forced_decoder_ids = None
        self.whisper_model.to(self.device)
        
        print("Loading speaker embedding model...")
        self.speaker_model = Model.from_pretrained(
            "pyannote/embedding",
            use_auth_token=hf_token
        ).to(self.device)
        
        self.speaker_database = {}
        self.speaker_name_mapping = {}
        self.sample_rate = 16000

    def add_speaker_reference(self, name: str, audio_file: str):
        """Add a reference audio sample for a speaker"""
        waveform, sample_rate = torchaudio.load(audio_file)
        if sample_rate != self.sample_rate:
            waveform = torchaudio.functional.resample(waveform, sample_rate, self.sample_rate)
        
        # Extract embedding
        with torch.no_grad():
            embedding = self.speaker_model(waveform.to(self.device))
        
        self.speaker_database[name] = {
            'waveform': waveform.squeeze(0).to(self.device),
            'embedding': embedding
        }
        print(f"Added reference sample for speaker: {name}")

    def diarize_audio(self, audio_file: str) -> List[SpeakerSegment]:
        """Perform speaker diarization on an audio file"""
        print("Running speaker diarization...")
        diarization = self.diarization_pipeline(audio_file)
        
        segments = []
        for segment, _, speaker in diarization.itertracks(yield_label=True):
            segments.append(SpeakerSegment(
                start=segment.start,
                end=segment.end,
                speaker=speaker
            ))
        
        print(f"Found {len(segments)} speaker segments")
        return segments

    def transcribe_segments(self, audio_file: str, segments: List[SpeakerSegment]) -> List[SpeakerSegment]:
        """Transcribe each speaker segment using Whisper"""
        print("Loading audio file for transcription...")
        waveform, sample_rate = torchaudio.load(audio_file)
        
        if sample_rate != self.sample_rate:
            waveform = torchaudio.functional.resample(waveform, sample_rate, self.sample_rate)
        
        waveform = waveform.squeeze(0).numpy()
        
        print("Transcribing segments...")
        for segment in segments:
            start_sample = int(segment.start * self.sample_rate)
            end_sample = int(segment.end * self.sample_rate)
            segment_audio = waveform[start_sample:end_sample]
            
            input_features = self.whisper_processor(
                segment_audio,
                sampling_rate=self.sample_rate,
                return_tensors="pt"
            ).input_features.to(self.device)
            
            predicted_ids = self.whisper_model.generate(input_features)
            segment.text = self.whisper_processor.batch_decode(predicted_ids, skip_special_tokens=True)[0]
        
        return segments

    def identify_speakers(self, audio_file: str, segments: List[SpeakerSegment]) -> List[SpeakerSegment]:
        """Identify speakers by comparing to reference samples"""
        if not self.speaker_database:
            print("No reference samples available - using original speaker labels")
            return segments
            
        print("Identifying speakers using reference samples...")
        return self.identify_speakers_with_references(audio_file, segments)

    def identify_speakers_with_references(self, audio_file: str, segments: List[SpeakerSegment]) -> List[SpeakerSegment]:
        """Identify speakers by comparing to reference samples"""
        print("Loading audio file for speaker identification...")
        waveform, sample_rate = torchaudio.load(audio_file)
        if sample_rate != self.sample_rate:
            waveform = torchaudio.functional.resample(waveform, sample_rate, self.sample_rate)
        waveform = waveform.to(self.device)
        
        speaker_groups = {}
        for segment in segments:
            if segment.speaker not in speaker_groups:
                speaker_groups[segment.speaker] = segment
        
        print("Identifying speakers...")
        speaker_mapping = {}
        for speaker, segment in speaker_groups.items():
            start_sample = int(segment.start * self.sample_rate)
            end_sample = int(segment.end * self.sample_rate)
            segment_audio = waveform[:, start_sample:end_sample]
            
            # Extract embedding for current segment
            with torch.no_grad():
                seg_emb = self.speaker_model(segment_audio)
            
            best_score = -1
            best_speaker = None
            
            for ref_name, ref_data in self.speaker_database.items():
                score = torch.nn.functional.cosine_similarity(
                    seg_emb, 
                    ref_data['embedding'], 
                    dim=1
                ).mean().item()
                
                if score > best_score:
                    best_score = score
                    best_speaker = ref_name
            
            if best_score > 0.7:  # Confidence threshold
                speaker_mapping[speaker] = best_speaker
                print(f"Identified {speaker} as {best_speaker} (score: {best_score:.2f})")
        
        # Apply mappings to all segments
        for segment in segments:
            if segment.speaker in speaker_mapping:
                segment.speaker = speaker_mapping[segment.speaker]
        
        return segments

    def process_audio(self, audio_file: str, output_format: str = "txt") -> str:
        """Full processing pipeline"""
        print(f"\nStarting processing for: {audio_file}")
        
        # Step 1: Diarization
        segments = self.diarize_audio(audio_file)
        if not segments:
            return "Error: No speaker segments found"
        
        # Step 2: Transcription
        segments = self.transcribe_segments(audio_file, segments)
        
        # Step 3: Speaker Identification
        segments = self.identify_speakers(audio_file, segments)
        
        # Step 4: Format output
        if output_format == "txt":
            return self._format_text_output(segments)
        elif output_format == "json":
            return self._format_json_output(segments)
        else:
            raise ValueError(f"Unsupported output format: {output_format}")
    
    def _format_text_output(self, segments: List[SpeakerSegment]) -> str:
        """Format segments as readable text"""
        output = []
        for segment in segments:
            if(segment.speaker=="SPEAKER_00"):
                segment.speaker="DOCTOR"
            if(segment.speaker=="SPEAKER_01" ):
                segment.speaker="PATIENT"
            output.append(
                f"{segment.speaker}: {segment.text}"
            # output.append(
            #     f"[{segment.start:.2f}-{segment.end:.2f}] {segment.speaker}: {segment.text}"
            )
        return "\n".join(output)
    
    def _format_json_output(self, segments: List[SpeakerSegment]) -> str:
        """Format segments as JSON"""
        segment_dicts = [
            {
                "start": segment.start,
                "end": segment.end,
                "speaker": segment.speaker,
                "text": segment.text
            }
            for segment in segments
        ]
        return json.dumps(segment_dicts, indent=2)

if __name__ == "__main__":
    print("Initializing speaker diarization system...")
    
    try:
        # Get your Hugging Face token from https://huggingface.co/settings/tokens
        HF_TOKEN = "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"  # Replace with your actual token
        
        system = SpeakerDiarizationSystem(hf_token=HF_TOKEN)
        
        # Add reference speakers (optional)
        # system.add_speaker_reference("John", "john_sample.wav")
        # system.add_speaker_reference("Sarah", "sarah_sample.wav")
        
        AUDIO_FILE = "mul_audio.wav"  # Replace with your audio file
        OUTPUT_FORMAT = "txt"  # "txt" or "json"
        
        result = system.process_audio(AUDIO_FILE, output_format=OUTPUT_FORMAT)
        
        # Save results
        output_file = f"output_result.{OUTPUT_FORMAT}"
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(result)
        
        print("\nProcessing complete!")
        print(f"Results saved to {output_file}")
        
    except Exception as e:
        print(f"\nError during processing: {e}")
        print("Troubleshooting steps:")
        print("1. Verify your Hugging Face token is valid")
        print("2. Check the audio file exists and is in supported format")
        print("3. Ensure all dependencies are installed (torch, torchaudio, pyannote.audio, transformers)")
        print("4. Try running with a smaller audio file first")