import React, { useState, useEffect, useRef } from "react";
import { BiSolidDashboard, BiLogOut } from "react-icons/bi";
import { FiMenu } from "react-icons/fi";
import { MdMic, MdMicNone, MdVolumeUp } from "react-icons/md";
import { FaSpinner } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import DocPatientImage from "../assets/doc-patient.jpg";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { FaUserMd, FaUser } from "react-icons/fa"; // Added missing imports

const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

const Dashboard = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMicActive, setIsMicActive] = useState(false);
  const [transcript, setTranscript] = useState(""); // Changed to string for raw text
  const [isProcessing, setIsProcessing] = useState(false);
  const [isReportGenerating, setIsReportGenerating] = useState(false);
  const [error, setError] = useState(null);
  const [isMobile, setIsMobile] = useState(false);
  const [reportId, setReportId] = useState(null);
  const micRecorderRef = useRef(null);
  const wsRef = useRef(null);
  const audioChunksRef = useRef([]);
  const chatContainerRef = useRef(null);
  const navigate = useNavigate();

  const userType = localStorage.getItem("userRole") || "doctor";
  const doctorName = "Dr. Harsh K.";
  const patientName = "Jane Doe";

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 640);
      setIsSidebarOpen(window.innerWidth >= 640);
    };
    handleResize();
    window.addEventListener("resize", handleResize);

    const connectWebSocket = () => {
      // wsRef.current = new WebSocket("ws://backend:8765");
      // const wsUrl = "ws://localhost:8765" || "ws://0.0.0.0:8765"; // Fallback for local dev
      const wsUrl = import.meta.env.VITE_WS_URL; 
      wsRef.current = new WebSocket(wsUrl);
      wsRef.current.onopen = () => {
        console.log("WebSocket connected");
        setError(null);
      };
      wsRef.current.onmessage = async (event) => {
        const data = JSON.parse(event.data);
        if (data.status === "success") {
          setTranscript(data.diarized_text); // Set raw diarized text directly
          setIsProcessing(false);
          setIsReportGenerating(true);
          await generateReportFromTranscript(data.diarized_text); // Pass raw text to report generation
          setIsReportGenerating(false);
        } else if (data.error) {
          setError(`Server error: ${data.error}`);
          setIsProcessing(false);
        }
      };
      wsRef.current.onerror = (err) => {
        console.error("WebSocket error:", err);
        setError("Failed to connect to WebSocket server at ws://localhost:8765.");
        setIsProcessing(false);
      };
      wsRef.current.onclose = () => {
        console.log("WebSocket closed");
        setTimeout(connectWebSocket, 2000);
      };
    };
    connectWebSocket();

    testGeminiConnection();

    return () => {
      window.removeEventListener("resize", handleResize);
      if (wsRef.current && wsRef.current.readyState !== WebSocket.CLOSED) {
        wsRef.current.close();
      }
      if (micRecorderRef.current) {
        micRecorderRef.current.stop();
        micRecorderRef.current.stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [transcript]);

  const testGeminiConnection = async () => {
    try {
      const result = await model.generateContent("Test connection");
      console.log("Gemini API working:", result.response.text());
    } catch (err) {
      setError(`Gemini API connection failed: ${err.message}`);
    }
  };

  const generateReportFromTranscript = async (diarizedText) => {
    if (!diarizedText) {
      setError("No transcript available to generate report");
      setIsReportGenerating(false);
      return;
    }

    const prompt = `
      Using the following doctor-patient conversation transcript, generate a medical report.
      Format the report with:
      1. Patient Information, date and time current according IST.
      2. Chief Complaint
      3. History of Present Illness
      4. Assessment and Plan
      Here is the conversation:
      ${diarizedText}
    `;
    try {
      const result = await model.generateContent(prompt);
      const reportContent = result.response.text();
      const newReportId = Date.now().toString();
      localStorage.setItem(`report_${newReportId}`, reportContent);
      setReportId(newReportId);
    } catch (err) {
      setError(`Error generating report: ${err.message}`);
    }
  };

  const toggleMic = async () => {
    if (!isMicActive) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        micRecorderRef.current = new MediaRecorder(stream, { mimeType: "audio/webm" });
        audioChunksRef.current = [];

        micRecorderRef.current.ondataavailable = (event) => {
          if (event.data.size > 0) audioChunksRef.current.push(event.data);
        };

        micRecorderRef.current.onstop = async () => {
          const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });
          console.log("Audio blob size:", audioBlob.size);
          const arrayBuffer = await audioBlob.arrayBuffer();
          const base64Audio = arrayBufferToBase64(arrayBuffer);

          if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            wsRef.current.send(JSON.stringify({ audio: base64Audio }));
            setIsProcessing(true);
          } else {
            setError("WebSocket not connected. Please try again.");
          }
        };

        micRecorderRef.current.start(2000);
        setIsMicActive(true);
        setTranscript(""); // Reset transcript on new consultation
        setReportId(null); // Reset report on new consultation
      } catch (err) {
        setError("Failed to start recording: " + err.message);
      }
    } else {
      micRecorderRef.current.stop();
      micRecorderRef.current.stream.getTracks().forEach((track) => track.stop());
      setIsMicActive(false);
    }
  };

  const arrayBufferToBase64 = (buffer) => {
    return btoa(new Uint8Array(buffer).reduce((data, byte) => data + String.fromCharCode(byte), ""));
  };

  const ProfileIcon = () => (
    <div className="relative">
      {userType === "doctor" ? (
        <FaUserMd className={`w-10 h-10 ${isMobile ? "w-6 h-6" : "text-indigo-300"}`} />
      ) : (
        <FaUser className={`w-10 h-10 ${isMobile ? "w-6 h-6" : "text-blue-300"}`} />
      )}
      <span className={`absolute bottom-0 right-0 ${isMobile ? "w-2 h-2" : "w-3 h-3"} bg-green-500 rounded-full border-2 border-white`}></span>
    </div>
  );

  const DesktopLayout = () => (
    <div className="flex h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <aside
        className={`${isSidebarOpen ? "w-72" : "w-20"} bg-gradient-to-b from-gray-900 to-indigo-900 text-white shadow-2xl transition-all duration-300 flex flex-col`}
      >
        <div className="p-6 flex items-center justify-between">
          {isSidebarOpen && <h2 className="text-2xl font-extrabold tracking-wide animate-fade-in">Consultation Assistant</h2>}
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 rounded-full hover:bg-indigo-800 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <FiMenu size={24} className="hover:text-indigo-300" />
          </button>
        </div>
        <nav className="mt-8 flex-1">
          <ul className="space-y-4 px-3">
            <li>
              <button className="flex items-center w-full p-3 rounded-lg hover:bg-indigo-800 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <BiSolidDashboard size={24} />
                {isSidebarOpen && <span className="ml-4 font-medium">Dashboard</span>}
              </button>
              <button
                onClick={() => {
                  localStorage.removeItem("userRole");
                  navigate("/");
                }}
                className="flex items-center w-full p-3 rounded-lg hover:bg-red-700 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-red-500"
              >
                <BiLogOut size={24} />
                {isSidebarOpen && <span className="ml-4 font-medium">Logout</span>}
              </button>
            </li>
          </ul>
        </nav>
        <div className="p-6 flex items-center space-x-3 border-t border-gray-700">
          <ProfileIcon />
          {isSidebarOpen && (
            <div className="text-sm">
              <p className="font-semibold">{userType === "doctor" ? doctorName : patientName}</p>
              <p className="text-indigo-200 capitalize">{userType}</p>
            </div>
          )}
        </div>
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white shadow-lg px-6 py-4 flex items-center justify-between">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <MdVolumeUp className="text-indigo-600" />
            Doctor Patient Consultation
          </h1>
          <div className="text-sm text-gray-600 font-medium">
            {new Date().toLocaleDateString("en-US", { dateStyle: "long" })}
          </div>
        </header>

        <main className="flex-1 p-8 bg-gray-50 flex flex-col">
          {error && (
            <div className="mb-8 p-4 bg-red-50 text-red-800 rounded-xl shadow-lg border-l-4 border-red-600 animate-slide-in flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {error}
            </div>
          )}

          <div className="grid grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl shadow-lg p-8 flex flex-col h-[500px] transform hover:scale-102 transition-all duration-300 overflow-hidden relative">
              <div className="absolute inset-0 bg-cover bg-center z-0" style={{ backgroundImage: `url(${DocPatientImage})` }} />
              <div className="absolute inset-0 z-10"></div>
              <div className="relative z-20 flex flex-col items-center justify-start pt-4">
                {isMicActive ? (
                  <MdMic size={72} className="text-green-500 animate-pulse" />
                ) : (
                  <MdMicNone size={72} className="text-black drop-shadow-lg" />
                )}
                <p className="mt-1 text-xl font-semibold text-black drop-shadow-lg">
                  {isMicActive ? "Recording Active" : "Ready to Record"}
                </p>
                {isMicActive && (
                  <span className="mt-1 text-sm text-green-500 animate-fade-in drop-shadow-lg">Listening to you...</span>
                )}
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8 flex flex-col h-[500px]">
              <h3 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <MdVolumeUp className="text-indigo-600" />
                Consultation Transcript
              </h3>
              <div
                ref={chatContainerRef}
                className="flex-1 bg-gray-100 rounded-xl p-4 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200 flex flex-col gap-4"
              >
                {isProcessing || isReportGenerating ? (
                  <div className="flex-1 flex items-center justify-center">
                    <FaSpinner className="animate-spin text-indigo-600 text-2xl" />
                    <p className="ml-2 text-gray-800">
                      {isProcessing ? "Processing audio..." : "Generating report..."}
                    </p>
                  </div>
                ) : transcript ? (
                  <div className="flex flex-col gap-4">
                    <pre className="text-sm text-gray-800 whitespace-pre-wrap">{transcript}</pre>
                    {reportId && (
                      <div className="flex justify-center mt-4">
                        <button
                          onClick={() => navigate(`/report/${reportId}`)}
                          className="bg-indigo-600 text-white px-8 py-3 rounded-full shadow-lg hover:bg-indigo-700 transform hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                          View Generated Report
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex-1 flex items-center justify-center">
                    <p className="text-gray-500 text-center animate-pulse">
                      {isMicActive ? "Recording in progress..." : "Start consultation to process audio"}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="mt-8 flex justify-center gap-6">
            <button
              onClick={toggleMic}
              className={`px-10 py-4 rounded-full text-white font-semibold shadow-xl transform transition-all duration-300 flex items-center gap-2 ${
                isMicActive
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-green-600 hover:bg-green-700 hover:scale-105 focus:ring-2 focus:ring-green-500"
              }`}
              disabled={isMicActive}
            >
              <MdMic size={24} />
              Start Consultation
            </button>
            <button
              onClick={toggleMic}
              className={`px-10 py-4 rounded-full text-white font-semibold shadow-xl transform transition-all duration-300 flex items-center gap-2 ${
                !isMicActive
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-red-600 hover:bg-red-700 hover:scale-105 focus:ring-2 focus:ring-red-500"
              }`}
              disabled={!isMicActive}
            >
              <MdMicNone size={24} />
              End Consultation
            </button>
          </div>
        </main>
      </div>
    </div>
  );

  const MobileLayout = () => (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-20 sm:w-64 bg-gradient-to-b from-gray-900 to-indigo-900 text-white shadow-2xl transition-all duration-300 flex flex-col ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="p-3 sm:p-4 flex items-center justify-between">
          {isSidebarOpen && (
            <h2 className="text-lg sm:text-xl font-extrabold tracking-wide animate-fade-in sm:block hidden">
              Consultation Assistant
            </h2>
          )}
          <button
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 rounded-full hover:bg-indigo-800 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <FiMenu size={20} className="sm:size-24 hover:text-indigo-300" />
          </button>
        </div>
        <nav className="mt-4 flex-1">
          <ul className="space-y-4 px-2 sm:px-3">
            <li>
              <button className="flex items-center w-full p-2 sm:p-3 rounded-lg hover:bg-indigo-800 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <BiSolidDashboard size={20} className="sm:size-24" />
                {isSidebarOpen && <span className="ml-3 font-medium sm:block hidden">Dashboard</span>}
              </button>
              <button
                onClick={() => {
                  localStorage.removeItem("userRole");
                  navigate("/");
                }}
                className="flex items-center w-full p-2 sm:p-3 rounded-lg hover:bg-red-700 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-red-500"
              >
                <BiLogOut size={20} className="sm:size-24" />
                {isSidebarOpen && <span className="ml-3 font-medium sm:block hidden">Logout</span>}
              </button>
            </li>
          </ul>
        </nav>
        <div className="p-3 sm:p-4 flex items-center space-x-2 sm:space-x-3 border-t border-gray-700">
          <ProfileIcon />
          {isSidebarOpen && (
            <div className="text-xs sm:text-sm sm:block hidden">
              <p className="font-semibold">{userType === "doctor" ? doctorName : patientName}</p>
              <p className="text-indigo-200 capitalize">{userType}</p>
            </div>
          )}
        </div>
      </aside>

      <div className="flex-1 flex flex-col sm:ml-20">
        <header className="bg-white shadow-lg px-3 py-2 sm:px-4 sm:py-3 flex items-center justify-between">
          <button
            onClick={() => setIsSidebarOpen(true)}
            className="sm:hidden p-2 rounded-full hover:bg-gray-200 transition-colors duration-200 focus:outline-none"
          >
            <FiMenu size={20} className="text-gray-900" />
          </button>
          <h1 className="text-lg sm:text-xl font-bold text-gray-900 flex items-center gap-2 flex-1 truncate">
            <MdVolumeUp className="text-indigo-600" />
            <span>Consultation</span>
          </h1>
          <div className="text-xs sm:text-sm text-gray-600 font-medium">
            {new Date().toLocaleDateString("en-US", { dateStyle: "medium" })}
          </div>
        </header>

        <main className="flex-1 p-3 sm:p-4 bg-gray-50 flex flex-col overflow-y-auto">
          {error && (
            <div className="mb-3 sm:mb-4 p-2 sm:p-3 bg-red-50 text-red-800 rounded-lg shadow-md border-l-4 border-red-600 animate-slide-in flex items-center gap-2 text-xs sm:text-sm">
              <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {error}
            </div>
          )}

          <div className="flex flex-col gap-3 sm:gap-4">
            <div className="bg-white rounded-lg shadow-md p-4 sm:p-6 flex flex-col h-64 sm:h-80 transform hover:scale-102 transition-all duration-300 overflow-hidden relative">
              <div className="absolute inset-0 bg-cover bg-center z-0" style={{ backgroundImage: `url(${DocPatientImage})` }} />
              <div className="absolute inset-0 z-10"></div>
              <div className="relative z-20 flex flex-col items-center justify-start pt-3 sm:pt-4">
                {isMicActive ? (
                  <MdMic size={36} className="sm:size-48 text-green-500 animate-pulse" />
                ) : (
                  <MdMicNone size={36} className="sm:size-48 text-black drop-shadow-lg" />
                )}
                <p className="mt-1 text-base sm:text-lg font-semibold text-black drop-shadow-lg">
                  {isMicActive ? "Recording" : "Ready"}
                </p>
                {isMicActive && (
                  <span className="mt-1 text-xs sm:text-sm text-green-500 animate-fade-in drop-shadow-lg">Listening...</span>
                )}
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-md p-4 sm:p-6 flex flex-col h-64 sm:h-80">
              <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-2 sm:mb-4 flex items-center gap-2">
                <MdVolumeUp className="text-indigo-600" />
                Consultation Transcript
              </h3>
              <div
                ref={chatContainerRef}
                className="flex-1 bg-gray-100 rounded-lg p-3 sm:p-4 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200 flex flex-col gap-3 sm:gap-4"
              >
                {isProcessing || isReportGenerating ? (
                  <div className="flex-1 flex items-center justify-center">
                    <FaSpinner className="animate-spin text-indigo-600 text-xl sm:text-2xl" />
                    <p className="ml-2 text-gray-800 text-xs sm:text-sm">
                      {isProcessing ? "Processing audio..." : "Generating report..."}
                    </p>
                  </div>
                ) : transcript ? (
                  <div className="flex flex-col gap-3 sm:gap-4">
                    <pre className="text-xs sm:text-sm text-gray-800 whitespace-pre-wrap">{transcript}</pre>
                    {reportId && (
                      <div className="flex justify-center mt-2 sm:mt-4">
                        <button
                          onClick={() => navigate(`/report/${reportId}`)}
                          className="bg-indigo-600 text-white px-4 sm:px-6 py-1 sm:py-2 rounded-full shadow-lg hover:bg-indigo-700 transform hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm"
                        >
                          View Generated Report
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex-1 flex items-center justify-center">
                    <p className="text-gray-500 text-center text-xs sm:text-sm animate-pulse">
                      {isMicActive ? "Recording in progress..." : "Start consultation to process audio"}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="mt-4 sm:mt-6 flex flex-col sm:flex-row justify-center gap-3 sm:gap-4">
            <button
              onClick={toggleMic}
              className={`px-6 py-2 sm:px-8 sm:py-3 rounded-full text-white font-semibold shadow-lg transform transition-all duration-300 flex items-center gap-2 text-xs sm:text-sm ${
                isMicActive
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-green-600 hover:bg-green-700 hover:scale-105 focus:ring-2 focus:ring-green-500"
              }`}
              disabled={isMicActive}
            >
              <MdMic size={16} className="sm:size-20" />
              Start Consultation
            </button>
            <button
              onClick={toggleMic}
              className={`px-6 py-2 sm:px-8 sm:py-3 rounded-full text-white font-semibold shadow-lg transform transition-all duration-300 flex items-center gap-2 text-xs sm:text-sm ${
                !isMicActive
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-red-600 hover:bg-red-700 hover:scale-105 focus:ring-2 focus:ring-red-500"
              }`}
              disabled={!isMicActive}
            >
              <MdMicNone size={16} className="sm:size-20" />
              End Consultation
            </button>
          </div>
        </main>
      </div>
    </div>
  );

  return isMobile ? <MobileLayout /> : <DesktopLayout />;
};

export default Dashboard;