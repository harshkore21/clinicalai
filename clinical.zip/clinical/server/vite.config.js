import { defineConfig } from 'vite';
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [
    react(), // Ensure React plugin is included
    tailwindcss(),
  ],
  define: {
    'process.env': {}, // For compatibility with some libraries
  },
  server: {
    host: '0.0.0.0', // Bind to all network interfaces
    port: 5173,      // Use the same port as in your Dockerfile
    allowedHosts: [
      'clinical.mebot.live', // Allow your custom domain
      'localhost',
      '127.0.0.1',
    ], // Explicitly allow these hosts
  },
});
